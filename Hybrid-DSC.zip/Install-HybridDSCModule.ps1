                Function Get-ScriptDirectory 
                {
                    ( $PSCommandPath , $PSISE.CurrentFile.FullPath )[ $PSISE -ne $Null ] | % {

                        [ PSCustomObject ]@{ 
            
                            Parent = Split-Path $_ -Parent
                            Leaf   = Split-Path $_ -Leaf 
                        }
                    }
                }
    
                Function Install-HybridDSCModule
                {
                    $Control          = [ PSCustomObject ]@{ 

                        Path          = $env:USERPROFILE
                        Target        = "Documents\WindowsPowerShell\Modules\Hybrid-DSC"
                        Chunk         = ""
                        Full          = ""
                        Source        = Get-ScriptDirectory | % { $_.Parent }
                    }
        
                    $Control          | % { 
        
                        $_.Full       = "{0}\{1}" -f $_.Path , $_.Target
                        $_.Chunk      = $_.Target.Split('\')
                        $Path         = $_.Path
                    }

                    ForEach ( $i in 0..( $Control.Chunk.Count - 1 ) )
                    {
                        $Leaf         = $Control.Chunk[$I]

                        If ( ! ( Test-Path "$Path\$Leaf" ) )
                        {
                            NI "$Path\$Leaf" -ItemType Directory | Out-Null
                            Write-Host "   Created [+] $Path" -F 11
                        }

                        Else
                        {
                            Write-Host "  Detected [~] $_" -F 11
                        }
                
                        $Path = "$Path\$Leaf"
                    }

                    If ( $Path -eq $Control.Full )
                    {
                        GCI $Control.Full | % { 
        
                            If ( $_ -ne $Null ) 
                            { 
                                Write-Host " Detected [!] $( $_.Name ), removing" -F 11 
                                RI $_.FullName -Recurse -Force 
                            }
                        }

                        $Control | % { 

                            ForEach ( $i in "Install-HybridDSCModule" )
                            {
                                If ( Test-Path "$( $_.Source )\$I.zip" )
                                {
                                    Write-Host "Extracting [~] $Path\$I" -F 14
                            
                                    Expand-Archive "$( $_.Source )\$I.zip" $_.Full -VB
                                }

                                Else
                                {
                                    Write-Host " Exception [!] Zip file not found"
                                }
                            }

                            ForEach ( $i in "Graphics" , "Control" , "Map" , "Services" ) 
                            {
                                Write-Host "Extracting [~] $( $_.Full )\$I.zip" -F 11
                        
                                Expand-Archive "$( $_.Full )\$I.zip" $_.Full
                        
                                RI "$Path\$I.zip"
                            }
                        }

                        IPMO Hybrid-DSC -Force
                    }
                }
    
                Install-HybridDSCModule

